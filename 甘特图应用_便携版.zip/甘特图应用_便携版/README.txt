甘特图应用程序使用说明

系统要求：
1. 安装Python (3.8或更高版本)
   - 从 https://www.python.org/downloads/ 下载
   - 安装时请勾选"Add Python to PATH"选项

使用方法：
1. 双击 launch.bat 启动程序
   - 首次运行时会自动安装必要的包
   - 程序会在默认浏览器中打开

2. 在应用程序中：
   - 左侧栏可以上传CSV文件
   - 上方显示项目概要信息
   - 主界面显示甘特图
   - 鼠标悬停可查看任务详情

数据文件格式：
CSV文件必须包含以下列：
* 工作序号: 任务编号
* 工作步骤: 任务名称
* 开始时间: DD/MM/YYYY格式
* 结束时间: DD/MM/YYYY格式
* 负责人: 任务负责人
* 备注: Task或Milestones

可参考 sample_template.csv 文件作为模板。

常见问题：
1. 如果启动失败，请确认：
   - Python是否已正确安装
   - 是否已将Python添加到系统环境变量
2. 如遇到"pip不是内部命令"错误：
   - 重新安装Python，确保勾选"Add Python to PATH"
3. 如遇到浏览器未自动打开：
   - 手动访问终端显示的本地URL（通常是 http://localhost:8501）